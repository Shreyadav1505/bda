#!/usr/bin/env python3
import sys

def get_grade(avg):
	avg = float(avg)
	if avg >= 90:
		return 'A'
	elif avg >= 80:
		return 'B'
	elif avg >= 70:
		return 'C'
	elif avg >= 60:
		return 'D'
	elif avg >= 50:
		return 'E'
	else:
		return 'F'

current_id = None
total = 0
count = 0

for line in sys.stdin:
	line = line.strip()
	if not line:
		continue
	student_id, marks = line.split('\t')
	marks = float(marks)
	if current_id == student_id:
		total += marks
		count += 1
	else:
		if current_id:
			avg = total / count
			print(f"{current_id}\t{avg}\t{get_grade(avg)}")
		current_id = student_id
		total = marks
		count = 1

if current_id:
	avg = total / count
	print(f"{current_id}\t{avg}\t{get_grade(avg)}")

