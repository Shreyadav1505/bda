#!/usr/bin/env python3
import sys
from collections import defaultdict

def emit_result(key, a_vals, b_vals):
	total = 0
	for k in a_vals:
		if k in b_vals:
			total += a_vals[k] * b_vals[k]
	print(f"{key}\t{total}")

current_key = None
a_vals = defaultdict(int)
b_vals = defaultdict(int)

for line in sys.stdin:
	line = line.strip()
	if not line:
		continue
	key, val = line.split('\t')
	if key != current_key and current_key is not None:
		emit_result(current_key, a_vals, b_vals)
		a_vals.clear()
		b_vals.clear()
	current_key = key
	matrix, p, v = val.split(',')
	p, v = int(p), int(v)
	if matrix == 'A':
		a_vals[p] = v
	elif matrix == 'B':
		b_vals[p] = v

if current_key is not None:
	emit_result(current_key, a_vals, b_vals)
