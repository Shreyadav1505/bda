#!/usr/bin/env python3
import sys
from collections import Counter
c = Counter()
[c.update({k:int(v)}) for l in sys.stdin for k,v in [l.strip().split('\t')]]
[print(f"{k}\t{v}") for k,v in c.items()]
