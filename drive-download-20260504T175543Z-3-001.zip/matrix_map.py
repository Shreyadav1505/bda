#!/usr/bin/env python3
import sys

for line in sys.stdin:
	line = line.strip()
	if not line:
		continue
	matrix, i, j, value = line.split(',')
	i, j, value = int(i), int(j), int(value)

	if matrix == 'A':
		for col in range(2):
			print(f"{i},{col}\tA,{j},{value}")
	elif matrix == 'B':
		for row in range(2):
			print(f"{row},{j}\tB,{i},{value}")

