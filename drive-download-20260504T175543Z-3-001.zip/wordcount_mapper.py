#!/usr/bin/env python3
import sys; [print(f"{w}\t1") for l in sys.stdin for w in l.strip().split()]

