#!/usr/bin/env python3
import sys

for line in sys.stdin:
	line = line.strip()
	if not line or line.startswith("student_id"):
		continue
	student_id, _, marks = line.split(',')
	print(f"{student_id}\t{marks}")

